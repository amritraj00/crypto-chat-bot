import React, { useState, FormEvent } from 'react';
import { Sword, Users, Map, Scroll, Sparkles, Dice1 as DiceD20, Send } from 'lucide-react';

type Category = 'character' | 'campaign' | 'quest';

interface Prompt {
  id: string;
  text: string;
  category: Category;
}

function App() {
  const [selectedCategory, setSelectedCategory] = useState<Category>('character');
  const [generatedContent, setGeneratedContent] = useState<string>('');
  const [customPrompt, setCustomPrompt] = useState('');

  const prompts: Record<Category, Prompt[]> = {
    character: [
      { id: '1', text: 'Generate a mysterious elven ranger with a dark past', category: 'character' },
      { id: '2', text: 'Create a chaotic good dwarf artificer who loves explosions', category: 'character' },
      { id: '3', text: 'Design a tiefling warlock bound to an ancient dragon', category: 'character' },
    ],
    campaign: [
      { id: '4', text: 'A kingdom threatened by an ancient curse awakening', category: 'campaign' },
      { id: '5', text: 'Pirates searching for a legendary artifact in the Astral Sea', category: 'campaign' },
      { id: '6', text: 'A mysterious plague turning people into mindless creatures', category: 'campaign' },
    ],
    quest: [
      { id: '7', text: 'Investigate disappearances in a small village', category: 'quest' },
      { id: '8', text: 'Retrieve a powerful artifact from a dragon\'s lair', category: 'quest' },
      { id: '9', text: 'Stop a cult from summoning an elder evil', category: 'quest' },
    ],
  };

  const handlePromptClick = (prompt: Prompt) => {
    setCustomPrompt(prompt.text);
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!customPrompt.trim()) return;

    const response = generateResponse(customPrompt);
    setGeneratedContent((prev) => 
      prev ? `${prev}\n\n---\n\n${response}` : response
    );
    setCustomPrompt('');
  };

  const generateResponse = (promptText: string) => {
    const responses: Record<string, string> = {
      'Generate a mysterious elven ranger with a dark past': 'Thaelar Moonwhisper, an elven ranger who witnessed the destruction of their homeland by dark forces. Now they track down magical artifacts to prevent them from falling into the wrong hands. Proficient in stealth and archery, they prefer to work alone but will join causes they deem worthy.',
      'Create a chaotic good dwarf artificer who loves explosions': 'Grimble Bangmaker, a dwarf artificer whose workshop has exploded exactly 47 times (so far). Despite the chaos, their inventions usually work... eventually. They\'re always eager to test new devices in combat, much to their companions\' concern.',
      'Design a tiefling warlock bound to an ancient dragon': 'Lilith Ashborn, a tiefling warlock whose pact with an ancient copper dragon grants them unique abilities. The dragon seeks to restore balance to the world, using Lilith as their agent of change.',
      'A kingdom threatened by an ancient curse awakening': 'An ancient curse laid upon the kingdom of Aldermere by a vengeful archfey is awakening after 1000 years. The royal family\'s firstborn children are disappearing one by one, and strange creatures emerge from the Feywild at night.',
      'Pirates searching for a legendary artifact in the Astral Sea': 'The legendary Ship of the Gods was last seen sailing the Astral Sea. Pirates from across the planes race to find it, believing it contains artifacts of immense power. But the ship may not be what it seems...',
      'A mysterious plague turning people into mindless creatures': 'A mysterious illness is spreading through the realm, turning people into crystal statues that whisper dark secrets. The source seems to be an ancient underground laboratory, but those who venture inside never return.',
      'Investigate disappearances in a small village': 'Children have been vanishing from the village of Ravenbrook. Locals blame a witch in the woods, but the truth involves a hidden portal to the Shadowfell and a collector of young souls.',
      'Retrieve a powerful artifact from a dragon\'s lair': 'An ancient bronze dragon guards a powerful artifact in their volcanic lair. However, the dragon might be willing to part with it - for the right price or service.',
      'Stop a cult from summoning an elder evil': 'The Crimson Circle cult believes they\'ve found the ritual to summon Dendar, the Night Serpent. They must be stopped before the next new moon, or eternal darkness will consume the world.',
    };
    return responses[promptText] || `Generated response for: "${promptText}"`;
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col">
      <header className="bg-gray-800 py-4 px-6 shadow-lg">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <DiceD20 className="h-8 w-8 text-purple-500" />
            <div>
              <h1 className="text-2xl font-bold text-purple-400">D&D Adventure Forge</h1>
              <p className="text-sm text-gray-400">Your AI Dungeon Master's Assistant</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setSelectedCategory('character')}
              className={`flex items-center px-3 py-1.5 rounded-md text-sm transition-all ${
                selectedCategory === 'character'
                  ? 'bg-purple-700 text-white'
                  : 'bg-gray-700 hover:bg-gray-600'
              }`}
            >
              <Users className="w-4 h-4 mr-1" /> Characters
            </button>
            <button
              onClick={() => setSelectedCategory('campaign')}
              className={`flex items-center px-3 py-1.5 rounded-md text-sm transition-all ${
                selectedCategory === 'campaign'
                  ? 'bg-purple-700 text-white'
                  : 'bg-gray-700 hover:bg-gray-600'
              }`}
            >
              <Map className="w-4 h-4 mr-1" /> Campaigns
            </button>
            <button
              onClick={() => setSelectedCategory('quest')}
              className={`flex items-center px-3 py-1.5 rounded-md text-sm transition-all ${
                selectedCategory === 'quest'
                  ? 'bg-purple-700 text-white'
                  : 'bg-gray-700 hover:bg-gray-600'
              }`}
            >
              <Scroll className="w-4 h-4 mr-1" /> Quests
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto p-6 flex gap-6">
        <div className="w-1/3 bg-gray-800 rounded-lg shadow-xl overflow-hidden">
          <div className="p-4 bg-gray-700 border-b border-gray-600">
            <h2 className="text-lg font-semibold flex items-center">
              <Sword className="w-5 h-5 mr-2 text-purple-500" />
              Example Prompts
            </h2>
          </div>
          <div className="p-3 space-y-2">
            {prompts[selectedCategory].map((prompt) => (
              <button
                key={prompt.id}
                onClick={() => handlePromptClick(prompt)}
                className="w-full text-left p-3 rounded-md bg-gray-700 hover:bg-gray-600 transition-colors text-sm"
              >
                {prompt.text}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 bg-gray-800 rounded-lg shadow-xl overflow-hidden flex flex-col">
          <div className="p-4 bg-gray-700 border-b border-gray-600">
            <h2 className="text-lg font-semibold flex items-center">
              <Sparkles className="w-5 h-5 mr-2 text-purple-500" />
              Generated Content
            </h2>
          </div>
          <div className="flex-1 p-4 overflow-y-auto">
            <div className="bg-gray-700/50 rounded-lg p-4 h-full whitespace-pre-wrap">
              {generatedContent || 'Enter a prompt or select an example to generate content...'}
            </div>
          </div>
          <div className="p-4 bg-gray-700 border-t border-gray-600">
            <form onSubmit={handleSubmit} className="flex gap-2">
              <input
                type="text"
                value={customPrompt}
                onChange={(e) => setCustomPrompt(e.target.value)}
                placeholder="Enter your prompt here or select an example above..."
                className="flex-1 px-4 py-2 rounded-md bg-gray-600 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-purple-500"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSubmit(e);
                  }
                }}
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-md bg-purple-600 hover:bg-purple-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                disabled={!customPrompt.trim()}
              >
                <Send className="w-4 h-4" />
                Send
              </button>
            </form>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;